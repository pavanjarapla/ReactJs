import React, { useEffect, useState } from "react";
import { NavLink, useHistory } from "react-router-dom";
import "/node_modules/bootstrap/dist/css/bootstrap.min.css";
// Chakra imports
import {
  Box,
  Button,
  Checkbox,
  Flex,
  FormControl,
  FormLabel,
  Heading,
  Icon,
  Input,
  InputGroup,
  InputRightElement,
  Text,
  useColorModeValue,
} from "@chakra-ui/react";
// Custom components
import DefaultAuth from "layouts/auth/Default";
// Assets
import { MdOutlineRemoveRedEye } from "react-icons/md";
import { RiEyeCloseLine } from "react-icons/ri";
function SignIn() {
  // Chakra color mode
  const history = useHistory();
  const [Iswarning, setWarning] = useState(false);
  const textColor = useColorModeValue("navy.700", "white");
  const textColorSecondary = "gray.600";
  const textColorDetails = useColorModeValue("navy.700", "secondaryGray.600");
  const textColorBrand = useColorModeValue("brand.500", "white");
  const brandStars = useColorModeValue("brand.500", "brand.400");
  const [email, setEmail] = useState(null);
  const [password, setPassword] = useState(null);
  const [confirmPassword, setConfirmPassword] = useState(null);
  const [errorMessage, setErrorMessage] = useState("");
  const [show, setShow] = React.useState(false);
  const handleClick = () => setShow(!show);
  const [signIn, setSignIn] = useState(true);
  const [usersData, setUsersData] = useState(null);
  useEffect(() => {
    fetch("http://localhost:3001/api/all-data")
      .then((response) => {
        return response.json();
      })
      .then((res) => {
        setUsersData(res);
      })
      .catch((err) => {
        console.log(err.message);
      });
  });
  const handleAuthentication = async () => {
    alert("in handleAuthentication ")
    localStorage.setItem("token", "test123");
    
    localStorage.setItem("userName","Hanuma Ramavath");
    localStorage.setItem("user_email","a123@gmail.com");
    history.push("/admin/default");
    // try {
    //   const response = await fetch(
    //     "http://localhost:3001/api/authentication",
    //     {
    //       method: "POST",
    //       headers: {
    //         "Content-Type": "application/json",
    //       },
    //       body: JSON.stringify({
    //         email,
    //         password,
    //       }),
    //     }
    //   );
    //   if (response.status === 200) {
    //     const data = await response.json();
    //     console.log(data.token);
    //     localStorage.setItem("token", data.token);
    //     const user = usersData.Users.filter((user) => user.user_email === email);
    //     localStorage.setItem("userName",user[0].Name);
    //     localStorage.setItem("user_email",user[0].Email);
    //     history.push("/admin/default");
    //     // Here, you can handle the successful authentication
    //   } else {
    //     setWarning(true);
    //     setErrorMessage("Email or password is incorrect");
    //     console.log("Authentication failed");
    //   }
    // } catch (error) {
    //   console.log(error.message);
    // }
  };
  const handleSign = () => {
    setSignIn(!signIn);
  };
  const handleRegister = async () => {
    try {
      const response = await fetch("http://localhost:3001/api/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          user_email: email, // Replace with your form input names
          password: password,
        }),
      });
      if (response.status === 201) {
        // Registration successful, you can redirect or show a success message
        console.log("Registration successful");
        setWarning(false);
        window.location.reload();
      } else {
        // Handle registration error, e.g., email already exists
        console.log("Registration failed");
        setWarning(true);
        setErrorMessage("You already have an account. Please Sign In");
      }
    } catch (error) {
      console.log(error.message);
    }
  };
  const handleSignUp = () => {
    if (usersData) {
      const user = usersData.Users.filter((user) => user.user_email === email);
      let flag = false;
      if (user[0]) {
        if (user[0].user_role === "admin" || user[0].user_role === "owner") {
          handleRegister();
          setEmail("");
          setPassword("");
          setConfirmPassword("");
          if (!Iswarning) {
            setSignIn(!signIn);
          }
          flag = true;
        } else {
          flag = false;
          setWarning(true);
          setErrorMessage("sorry you're not an admin");
        }
      } else {
        setWarning(true);
        setErrorMessage("sorry it's not a valid email");
      }
      console.log(flag);
    }
  };
  return (
    <DefaultAuth>
      <Flex w="100%" h="100vh" alignItems="center" justifyContent="center">
        {signIn ? (
          <Flex
            maxW={{ base: "100%", md: "max-content" }}
            w="100%"
            mx={{ base: "auto", lg: "0px" }}
            me="auto"
            flexDirection="column"
          >
            {Iswarning && (
              <div class="alert alert-danger d-flex align-items-center">
                <svg
                  class="bi flex-shrink-0 me-2"
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  fill="currentColor"
                  className="bi bi-exclamation-triangle-fill"
                  viewBox="0 0 16 16"
                >
                  <path d="M0 8.265a.733.733 0 0 1 .368-.635l6.933-3.973a.733.733 0 0 1 .734 0l6.933 3.973a.733.733 0 0 1 .367.635V12a.733.733 0 0 1-.368.635l-6.933 3.973a.733.733 0 0 1-.734 0l-6.933-3.973A.733.733 0 0 1 0 12V8.265zM7 10a1 1 0 0 0 1-1V5a1 1 0 0 0-2 0v4a1 1 0 0 0 1 1zm1 1a1 1 0 0 0-1 1 1 1 0 0 0 2 0 1 1 0 0 0-1-1z" />
                </svg>
                <div>{errorMessage}</div>
              </div>
            )}
            <Box me="auto">
              <Heading color={textColor} fontSize="36px" mb="10px">
                Sign In
              </Heading>
              <Text
                mb="10px"
                ms="4px"
                color={textColorSecondary}
                fontWeight="400"
                fontSize="md"
              >
                Enter your email and password to Sign In.{" "}
                <b style={{ color: "black" }}>Only for Admin's !!!</b>
              </Text>
            </Box>
            <Flex
              zIndex="2"
              direction="column"
              w={{ base: "100%", md: "420px" }}
              maxW="100%"
              background="transparent"
              borderRadius="15px"
              mx={{ base: "auto", lg: "unset" }}
              me="auto"
              mb={{ base: "20px", md: "auto" }}
            >
              <FormControl id="myForm">
                <FormLabel
                  display="flex"
                  ms="4px"
                  fontSize="sm"
                  fontWeight="500"
                  color={textColor}
                  mb="8px"
                >
                  Email Id<Text color={brandStars}>*</Text>
                </FormLabel>
                <Input
                  isRequired="true"
                  variant="auth"
                  fontSize="sm"
                  ms={{ base: "0px", md: "0px" }}
                  type="email"
                  placeholder="Firstname.Surname@techwave.net"
                  mb="24px"
                  fontWeight="500"
                  size="lg"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
                <FormLabel
                  ms="4px"
                  fontSize="sm"
                  fontWeight="500"
                  color={textColor}
                  display="flex"
                >
                  Password<Text color={brandStars}>*</Text>
                </FormLabel>
                <InputGroup size="md">
                  <Input
                    isRequired={true}
                    fontSize="sm"
                    placeholder="Min. 8 characters"
                    mb="24px"
                    size="lg"
                    type={show ? "text" : "password"}
                    variant="auth"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                  <InputRightElement
                    display="flex"
                    alignItems="center"
                    mt="4px"
                  >
                    <Icon
                      color={textColorSecondary}
                      _hover={{ cursor: "pointer" }}
                      as={show ? RiEyeCloseLine : MdOutlineRemoveRedEye}
                      onClick={handleClick}
                    />
                  </InputRightElement>
                </InputGroup>

                <Flex justifyContent="space-between" align="center" mb="24px">
                  <FormControl display="flex" alignItems="center">
                    <Checkbox
                      id="remember-login"
                      colorScheme="brandScheme"
                      me="10px"
                    />
                    <FormLabel
                      htmlFor="remember-login"
                      mb="0"
                      fontWeight="normal"
                      color={textColor}
                      fontSize="sm"
                    >
                      Keep me logged in
                    </FormLabel>
                  </FormControl>
                  <NavLink to="/auth/forgot-password">
                    <Text
                      color={textColorBrand}
                      fontSize="sm"
                      w="124px"
                      fontWeight="500"
                    >
                      Forgot password?
                    </Text>
                  </NavLink>
                </Flex>
                <Button
                  onClick={handleAuthentication}
                  fontSize="sm"
                  variant="brand"
                  fontWeight="500"
                  w="100%"
                  h="50"
                  mb="24px"
                >
                  Sign In
                </Button>
              </FormControl>
              <Flex
                flexDirection="column"
                justifyContent="center"
                alignItems="start"
                maxW="100%"
                mt="0px"
              >
                <Text color={textColorDetails} fontWeight="400" fontSize="14px">
                  Not registered yet?
                  <Text
                    color={textColorBrand}
                    as="span"
                    ms="5px"
                    fontWeight="500"
                    onClick={handleSign}
                    cursor="pointer"
                  >
                    Create an Account
                  </Text>
                </Text>
              </Flex>
            </Flex>
          </Flex>
        ) : (
          <Flex
            maxW={{ base: "100%", md: "max-content" }}
            w="100%"
            mx={{ base: "auto", lg: "0px" }}
            me="auto"
            flexDirection="column"
          >
            {Iswarning && (
              <div class="alert alert-danger d-flex align-items-center">
                <svg
                  class="bi flex-shrink-0 me-2"
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  fill="currentColor"
                  className="bi bi-exclamation-triangle-fill"
                  viewBox="0 0 16 16"
                >
                  <path d="M0 8.265a.733.733 0 0 1 .368-.635l6.933-3.973a.733.733 0 0 1 .734 0l6.933 3.973a.733.733 0 0 1 .367.635V12a.733.733 0 0 1-.368.635l-6.933 3.973a.733.733 0 0 1-.734 0l-6.933-3.973A.733.733 0 0 1 0 12V8.265zM7 10a1 1 0 0 0 1-1V5a1 1 0 0 0-2 0v4a1 1 0 0 0 1 1zm1 1a1 1 0 0 0-1 1 1 1 0 0 0 2 0 1 1 0 0 0-1-1z" />
                </svg>
                <div>{errorMessage}</div>
              </div>
            )}
            {/* ... (other content) */}
            <Box me="auto">
              <Heading color={textColor} fontSize="36px" mb="10px">
                Create your account
              </Heading>
              <Text
                mb="10px"
                ms="4px"
                color={textColorSecondary}
                fontWeight="400"
                fontSize="md"
              >
                Enter your email and create password to Sign Up.{" "}
                <b style={{ color: "black" }}>Only for Admin's !!!</b>
              </Text>
            </Box>
            <Flex
              zIndex="2"
              direction="column"
              w={{ base: "100%", md: "420px" }}
              maxW="100%"
              background="transparent"
              borderRadius="15px"
              mx={{ base: "auto", lg: "unset" }}
              me="auto"
              mb={{ base: "20px", md: "auto" }}
            >
              <FormControl id="myForm">
                <FormLabel
                  display="flex"
                  ms="4px"
                  fontSize="sm"
                  fontWeight="500"
                  color={textColor}
                  mb="8px"
                >
                  Email Id<Text color={brandStars}>*</Text>
                </FormLabel>
                <Input
                  isRequired={true}
                  variant="auth"
                  fontSize="sm"
                  ms={{ base: "0px", md: "0px" }}
                  type="email"
                  placeholder="Firstname.Surname@techwave.net"
                  mb="24px"
                  fontWeight="500"
                  size="lg"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
                <FormLabel
                  ms="4px"
                  fontSize="sm"
                  fontWeight="500"
                  color={textColor}
                  display="flex"
                >
                  Password<Text color={brandStars}>*</Text>
                </FormLabel>
                <InputGroup size="md">
                  <Input
                    isRequired={true}
                    fontSize="sm"
                    placeholder="Min. 8 characters"
                    mb="24px"
                    size="lg"
                    type={show ? "text" : "password"}
                    variant="auth"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                  <InputRightElement
                    display="flex"
                    alignItems="center"
                    mt="4px"
                  >
                    <Icon
                      color={textColorSecondary}
                      _hover={{ cursor: "pointer" }}
                      as={show ? RiEyeCloseLine : MdOutlineRemoveRedEye}
                      onClick={handleClick}
                    />
                  </InputRightElement>
                </InputGroup>
                <FormLabel
                  ms="4px"
                  fontSize="sm"
                  fontWeight="500"
                  color={textColor}
                  display="flex"
                >
                  Confirm Password<Text color={brandStars}>*</Text>
                </FormLabel>
                <InputGroup size="md">
                  <Input
                    isRequired={true}
                    fontSize="sm"
                    placeholder="Min. 8 characters"
                    mb="24px"
                    size="lg"
                    type={show ? "text" : "password"}
                    variant="auth"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                  />
                  <InputRightElement
                    display="flex"
                    alignItems="center"
                    mt="4px"
                  >
                    <Icon
                      color={textColorSecondary}
                      _hover={{ cursor: "pointer" }}
                      as={show ? RiEyeCloseLine : MdOutlineRemoveRedEye}
                      onClick={handleClick}
                    />
                  </InputRightElement>
                </InputGroup>
                <Flex justifyContent="space-between" align="center" mb="24px">
                  <FormControl display="flex" alignItems="center">
                    <Checkbox
                      id="remember-login"
                      colorScheme="brandScheme"
                      me="10px"
                    />
                    <FormLabel
                      htmlFor="remember-login"
                      mb="0"
                      fontWeight="normal"
                      color={textColor}
                      fontSize="sm"
                    >
                      Keep me logged in
                    </FormLabel>
                  </FormControl>
                  <NavLink to="/auth/forgot-password">
                    <Text
                      color={textColorBrand}
                      fontSize="sm"
                      w="124px"
                      fontWeight="500"
                    >
                      Forgot password?
                    </Text>
                  </NavLink>
                </Flex>
                <Button
                  onClick={handleSignUp}
                  fontSize="sm"
                  variant="brand"
                  fontWeight="500"
                  w="100%"
                  h="50"
                  mb="24px"
                >
                  Sign Up
                </Button>
              </FormControl>
            </Flex>
            <Text color={textColorDetails} fontWeight="400" fontSize="14px">
              Have an account?
              <Text
                color={textColorBrand}
                as="span"
                ms="5px"
                fontWeight="500"
                onClick={handleSign}
                cursor="pointer"
              >
                Back to Sign In
              </Text>
            </Text>
          </Flex>
        )}
      </Flex>
    </DefaultAuth>
  );
}
export default SignIn;
