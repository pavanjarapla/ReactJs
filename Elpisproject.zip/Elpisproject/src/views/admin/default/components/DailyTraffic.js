import React, { useEffect, useState } from "react";
import {
  Box,
  Flex,
  Text,
  useColorModeValue,
  Select,
  Icon,
  Button,
} from "@chakra-ui/react";
import BarChart from "components/charts/BarChart";
import Card from "components/card/Card.js";
import { barChartOptionsDailyTraffic } from "variables/charts";
import { MdBarChart } from "react-icons/md";
//import{generateBarChartData} from "variables/charts";

export default function DailyTraffic(props) {
  const { ...rest } = props;
  const [selectedRegion, setSelectedRegion] = useState("All");
  const [fetchedData, setFetchedData] = useState({ Users: [] });
  const [averageCompletionRates, setAverageCompletionRates] = useState({});
  const [barChartData, setbarChartData] = useState(null); // Store the average completion rates

  useEffect(() => {
    async function fetchData() {
      try {
        const response = await fetch("http://localhost:3001/api/all-data");
        if (!response.ok) {
          throw new Error("Network response was not ok");
        }
        const data = await response.json();
        setFetchedData(data);

        //Calculate average completion rates for each region
        const regionData = {};
        const regionCounts = {};
        data.Users.forEach((user) => {
          const { Region, Paths } = user;
          if (!regionData[Region]) {
            regionData[Region] = 0;
            regionCounts[Region] = 0;
          }
          Paths.forEach((path) => {
            regionData[Region] += path.completion_ratio;
            regionCounts[Region]++;
          });
        });
        const avgCompletionRates = {};
        for (const region in regionData) {
          avgCompletionRates[region] =
            regionData[region] / regionCounts[region];
        }
        setAverageCompletionRates(avgCompletionRates);
        // console.log(JSON.stringify(averageCompletionRates));
        const regionList = Object.values(avgCompletionRates).map((rate) =>
          Math.round(rate)
        );
        setbarChartData(regionList);
      } catch (error) {
        console.log("Error fetching data:", error);
      }
    }

    fetchData();
  }, []);

  const textColorSecondary = useColorModeValue("secondaryGray.600", "white");
  const boxBg = useColorModeValue("secondaryGray.300", "whiteAlpha.100");
  const textColor = useColorModeValue("secondaryGray.900", "white");
  const iconColor = useColorModeValue("brand.500", "white");
  const bgButton = useColorModeValue("secondaryGray.300", "whiteAlpha.100");
  const bgHover = useColorModeValue(
    { bg: "secondaryGray.400" },
    { bg: "whiteAlpha.50" }
  );
  const bgFocus = useColorModeValue(
    { bg: "secondaryGray.300" },
    { bg: "whiteAlpha.100" }
  );
  return (
    barChartData && (
      <Card align="center" direction="column" w="100%" {...rest}>
            <Flex align="center" w="100%" px="15px" py="10px">
              <Text  me="auto" color={textColor} fontSize="2xl" fontWeight="700" lineHeight="100%">
                Region Wise Completion Rate
              </Text>
              <Button
                align="center"
                justifyContent="center"
                bg={bgButton}
                _hover={bgHover}
                _focus={bgFocus}
                _active={bgFocus}
                w="37px"
                h="37px"
                lineHeight="100%"
                borderRadius="10px"
              >
                <Icon as={MdBarChart} color={iconColor} w="24px" h="24px" />
              </Button>
            </Flex>

            {/* <Select
            alignSelf="flex-start"
            w="200px"
            bg={boxBg}
            fontSize="sm"
            fontWeight="500"
            color={textColorSecondary}
            borderRadius="7px"
            onChange={(e) => setSelectedRegion(e.target.value)}
            value={selectedRegion}
          >
            <option value="All">All</option>
            <option value="Ind">INDIA</option>
            <option value="NA">NA</option>
            <option value="Eu East">EU EAST</option>
            <option value="Eu West">EU WEST</option>
            <option value="ANZ">ANZ</option>
            <option value="GDC">GDC</option>
          </Select> */}
          {/* <Flex align="center">
          <Text color={textColor} fontSize="34px" fontWeight="700" lineHeight="100%">
            {filteredData.length}
          </Text>
          <Text ms="6px" color="secondaryGray.600" fontSize="sm" fontWeight="500">
            Users
          </Text>
        </Flex> */}
        <Box h="440px" mt="auto">
          <BarChart
            chartData={[
              {
                name: "Course Complition Rate",
                data: barChartData,
              },
            ]}
            chartOptions={barChartOptionsDailyTraffic}
          />
        </Box>
        <Text
          color={textColor}
          fontSize="20px"
          fontWeight="700"
          lineHeight="100%"
        >
          Course Completion Rate
        </Text>
      </Card>
    )
  );
}
