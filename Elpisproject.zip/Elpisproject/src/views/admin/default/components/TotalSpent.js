import React, { useEffect, useState } from "react";
import { VSeparator } from "components/separator/Separator";
import { Tooltip, Popover, PopoverTrigger, PopoverContent, PopoverHeader, PopoverBody } from "@chakra-ui/react";
import {
  Box,
  Button,
  Flex,
  Icon,
  Text,
  useColorModeValue,
  Select,
  FormControl
} from "@chakra-ui/react";
// Custom components
import Card from "components/card/Card.js";
import LineChart from "components/charts/LineChart";
import { IoCheckmarkCircle } from "react-icons/io5";
import { MdBarChart, MdLineAxis, MdLineStyle, MdLinearScale, MdMultilineChart, MdOutlineAddChart, MdOutlineCalendarToday, MdOutlineChairAlt, MdOutlineStackedLineChart, MdStackedLineChart } from "react-icons/md";
// Assets
import { RiArrowUpSFill } from "react-icons/ri";
//import { generateBarChartData1 } from "variables/charts";
import {
  lineChartOptionsTotalSpent,
} from "variables/charts";
import { position } from "stylis";
export default function TotalSpent(props) {
  const { ...rest } = props;
  const [lineChartDataTotalSpent, setlineChartDataTotalSpent] = useState(null);
  
  useEffect(() => {
    async function fetchDataAndProcessData() {
      async function fetchData() {
        const apiUrl = 'http://localhost:3001/api/all-data'; // Replace with your API URL
        try {
          const response = await fetch(apiUrl);
          if (!response.ok) {
            throw new Error('Network response was not ok');
          }
          const data = await response.json();
          return data.Users; // Extract the Users array from the data
        } catch (error) {
          console.error('Error fetching data:', error);
          return null;
        }
      }
      
       function processUserData(users) {
        const months = ['currentMonth', 'lastMonth', 'twoMonthsAgo', 'threeMonthsAgo'];
        
        const results = {
          enrollments: [0, 0, 0, 0],
          completions: [0, 0, 0, 0],
        };
      
        const currentDate=new Date();
        function isDateInMonth(date, monthOffset) {
          const dateToCheck = new Date(currentDate);
          dateToCheck.setMonth(dateToCheck.getMonth() - monthOffset);
          return (
            dateToCheck.getFullYear() === currentDate.getFullYear() &&
            dateToCheck.getMonth() === date.getMonth()
          );
        }
        users.forEach((user) => {
          user.Paths.forEach((path) => {
            path.courses.forEach((course) => {
              const enrollDate = new Date(course.course_enroll_date);
              const courseLastAccessedDate = new Date(course.course_last_accessed_date);
      
              for (let i = 0; i < months.length; i++) {
                if (isDateInMonth(enrollDate, i)) {
                  results.enrollments[((months.length)-(i+1))]++;
                  if (course.completion_ratio === 100 && isDateInMonth(courseLastAccessedDate, i)) {
                    results.completions[((months.length)-(i+1))]++;
                  }
                }
              }
            });
          });
        });
       
        return {
          enrollments: results.enrollments,
          completions: results.completions,
        };
        
      }
      let apiData;
      const data = await fetchData();
      if (data) {
        apiData = data;
        await processUserData(apiData);
      const { enrollments, completions } = processUserData(apiData);
      setlineChartDataTotalSpent([
        {
          name: "Completion",
          data: completions,
        },
        {
          name: "Enrolls",
          data: enrollments,
        }
      ]);
     }
    }
    fetchDataAndProcessData();
  }, []);
  // Chakra Color Mode
  const textColor = useColorModeValue("secondaryGray.900", "white");
  const textColorSecondary = useColorModeValue("secondaryGray.600", "white");
  const boxBg = useColorModeValue("secondaryGray.300", "whiteAlpha.100");
  const iconColor = useColorModeValue("brand.500", "white");
  const bgButton = useColorModeValue("secondaryGray.300", "whiteAlpha.100");
  const bgHover = useColorModeValue(
    { bg: "secondaryGray.400" },
    { bg: "whiteAlpha.50" }
  );
  const bgFocus = useColorModeValue(
    { bg: "secondaryGray.300" },
    { bg: "whiteAlpha.100" }
  );
  return (
    lineChartDataTotalSpent&&
    <Card justifyContent='center' align='center' direction='column' w='100%' mb='0px' {...rest}>
    <Flex align="center" w="100%" px="15px" py="10px">
    <Text me="auto" color={textColor} fontSize="2xl" fontWeight="700" lineHeight="100%">
      Monthly Report
    </Text>
    <Button
          align="center"
          justifyContent="center"
          bg={bgButton}
          _hover={bgHover}
          _focus={bgFocus}
          _active={bgFocus}
          w="37px"
          h="37px"
          lineHeight="100%"
          borderRadius="10px"
          {...rest}
        >
          <Icon as={MdStackedLineChart} color={iconColor} w="24px" h="24px" />
        </Button>
    </Flex>
    <Flex direction='column' py='5px'>
        <Flex align='center'>
          <Box h='8px' w='8px' bg='brand.500' borderRadius='50%' me='4px' />
          <Tooltip  hasArrow>
            <Text
              fontSize='xs'
              color='brand.500'
              fontWeight='700'
              mb='5px'>
              Completed Courses
            </Text>
          </Tooltip>
        </Flex>
      </Flex>
      <VSeparator mx={{ base: "60px", xl: "60px", "2xl": "60px" }} />
      <Flex direction='column' py='5px' me='10px'>
        <Flex align='center'>
          <Box h='8px' w='8px' bg='#6AD2FF' borderRadius='50%' me='4px' />
          <Tooltip  hasArrow>
            <Text
              fontSize='xs'
              color='#6AD2FF'
              fontWeight='700'
              mb='5px'>
              Enrolled Courses
            </Text>
          </Tooltip>
        </Flex>
      </Flex>
      
    <Flex w='100%' flexDirection={{ base: "column", lg: "row" }}>
      <Box minH='300px' minW='100%' mt='auto'>
        <LineChart
          chartData={lineChartDataTotalSpent}
          chartOptions={lineChartOptionsTotalSpent}
        />
      </Box>
    </Flex>
  </Card>
  

  );
}
