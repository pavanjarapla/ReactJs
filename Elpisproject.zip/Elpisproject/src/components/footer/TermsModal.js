import React from "react";
import { Button } from "@chakra-ui/react";
import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalCloseButton,
  ModalBody,
} from "@chakra-ui/react";

const modalContentStyle = {
  display: "flex",
  flexDirection: "column",
  alignItems: "center",
  padding: "20px",
  textAlign: "left",
};

const sectionHeaderStyle = {
  fontWeight: "bold",
  fontSize: "1.2rem",
  //marginTop: "0.5rem",
};

const paragraphStyle = {
  marginBottom: "1rem",
  lineHeight: "1.5",
};
const boldStyle = {
  fontWeight: "bold",
};
const closeButtonStyle = {
  backgroundColor: "#3333cc",
  color: "white",
  marginTop: "1rem",
};
const modalHeaderStyle = {
  fontSize: "25px",
};

const customBackdropOverlayStyle = {
  bg: "blackAlpha.300",
  backdropFilter: "blur(10px) hue-rotate(0deg)",
};

export default function TermsModal({ isOpen, onClose }) {
  return (
    <Modal isCentered isOpen={isOpen} onClose={onClose} size="3xl">
      <ModalOverlay style={customBackdropOverlayStyle} />
      <ModalContent>
        <ModalHeader style={modalHeaderStyle}>
          MY EYE Application Terms & Conditions
          <p style={{ fontSize: "18px" }}>Last Updated: 30th-Oct 2023</p>
        </ModalHeader>
        <ModalCloseButton />
        <ModalBody style={modalContentStyle}>
          <div style={{ maxHeight: "400px", overflowY: "auto" }}>
            <p style={sectionHeaderStyle}>1. Acceptance of Terms</p>
            <p style={paragraphStyle}>
              By accessing and using the MY EYE application, you agree to be
              bound by these Terms and Conditions. If you do not agree with any
              part of these terms, you must not use the application.
            </p>

            <p style={sectionHeaderStyle}>2. User Accounts</p>
            <p style={paragraphStyle}>
              2.1 Registration: Users, typically administrators, are required to
              create an account to access the MY EYE application. During
              registration, you must provide accurate and complete information.
            </p>
            <p style={paragraphStyle}>
              2.2 Account Security: You are responsible for maintaining the
              security of your account credentials. Any unauthorized use of your
              account must be reported to us immediately.
            </p>

            <p style={sectionHeaderStyle}>3. Usage and Access</p>
            <p style={paragraphStyle}>
              3.1 License: MY EYE grants you a non-exclusive, non-transferable,
              and limited license to access and use the application for your
              organization's internal purposes.
            </p>
            <p style={paragraphStyle}>
              3.2 Prohibited Activities: You agree not to:
            </p>
            <ul style={paragraphStyle}>
              <li>
                Use the application for any illegal or unauthorized purpose.
              </li>
              <li>Share login credentials with unauthorized individuals.</li>
              <li>
                Attempt to interfere with the proper functioning of the
                application.
              </li>
              <li>
                Collect data or personally identifiable information of users
                without their consent.
              </li>
            </ul>

            <p style={sectionHeaderStyle}>4. Data Collection and Privacy</p>
            <p style={paragraphStyle}>
              MY EYE may collect and process data about your use of the
              application. Please refer to our Privacy Policy for details on
              data collection and protection.
            </p>

            <p style={sectionHeaderStyle}>5. Learning Platform</p>
            <p style={paragraphStyle}>
              5.1 Learning Courses: MY EYE provides a platform for administrators
              to assign courses to employees. Administrators can also track the
              progress and completion of these courses.
            </p>
            <p style={paragraphStyle}>
              5.2 Learning Paths: Administrators can assign learning paths to
              employees and monitor the paths' progress. This includes
              information on who assigned the paths.
            </p>

            <p style={sectionHeaderStyle}>6. Data Filtering</p>
            <p style={paragraphStyle}>
              MY EYE allows administrators to filter data by regions, business
              units, and other criteria for tracking and analysis.
            </p>

            <p style={sectionHeaderStyle}>7. Usage Statistics</p>
            <p style={paragraphStyle}>
              7.1 Administrators can access usage statistics of employees, such
              as time spent on the platform and the number of courses completed.
            </p>
            <p style={paragraphStyle}>
              7.2 Reports: Administrators can generate weekly and monthly
              reports to track employee learning activities.
            </p>

            <p style={sectionHeaderStyle}>8. Intellectual Property</p>
            <p style={paragraphStyle}>
              The MY EYE application and its content are protected by
              intellectual property rights. Users must not use, reproduce, or
              distribute any part of the application without proper
              authorization.
            </p>

            <p style={sectionHeaderStyle}>9. Termination</p>
            <p style={paragraphStyle}>
              MY EYE may suspend or terminate your access to the application at
              its discretion. You may also terminate your account at any time.
            </p>

            <p style={sectionHeaderStyle}>10. Changes to Terms</p>
            <p style={paragraphStyle}>
              MY EYE reserves the right to update and modify these Terms and
              Conditions. Users will be notified of any changes.
            </p>

            <p style={sectionHeaderStyle}>11. Contact Information</p>
            <p style={paragraphStyle}>
              For questions or concerns regarding these Terms and Conditions,
              please contact us at [Contact Email].
            </p>

            <p style={paragraphStyle}>
              By using the MY EYE application, you acknowledge that you have
              read, understood, and agreed to these Terms and Conditions.
            </p>

            <p style={paragraphStyle}>
              <span style={boldStyle}>Techwave Consulting</span>
            </p>
            <p style={paragraphStyle}>30/10/2023</p>
          </div>
          <Button style={closeButtonStyle} onClick={onClose}>
            Close
          </Button>
        </ModalBody>
      </ModalContent>
    </Modal>
  );
}
